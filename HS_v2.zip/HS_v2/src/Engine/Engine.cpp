#include "Engine/Engine.h"
#include <iostream>
#include <string>
#include "Hero/Hero.h"
#include <ctime>
Engine::Engine(Player &player1, Player &player2, Ui *ui) : playerLists{player1, player2}
{
    addUiObserver(ui);
}

void Engine::startGame()
{
    std::srand(std::time(0));
    // HeroType randomHeroIndex = (HeroType)(rand() % MAX_HERO);/
    playerLists[hostPlayerID].setHero(BUTCHER);
    // randomHeroIndex = (HeroType)(rand() % MAX_HERO);
    playerLists[clientPlayerID].setHero(SLARK);
    if (currentGameMode == UNKNOWN)
    {

        updateUi(Ui::INIT, playerLists, MAX_PLAYER, (unsigned int &)currentGameMode);
        for (int playerIndex = 0; playerIndex < (unsigned int)MAX_PLAYER; playerIndex++)
        {
            playerLists[playerIndex].drawCard(10);
        }
    }

    MySocket socket((unsigned int)currentGameMode);

    switch (currentGameMode)
    {
    case HOST:
    {
        auto &serverSocket = socket;
        startHostMode(&serverSocket);
        break;
    }
    case CLIENT:
    {
        auto &clientSocket = socket;
        for (int playerIndex = 0; playerIndex < (unsigned int)MAX_PLAYER; playerIndex++)
        {
            playerLists[playerIndex].getHand().clear();
        }
        startClientMode(&clientSocket);
        break;
    }
    default:
        startSingleMode();
        break;
    }
}

bool Engine::isEndGame(PlayerId playerID)
{
    return playerLists[playerID].getHero()->IsAlive();
}

void Engine::endTurn()
{
    std::swap(currentTurn, nextTurn);
}

int Engine::getTurn()
{
    return currentTurn;
}

void Engine::startHostMode(MySocket *host)
{
    if (host != nullptr)
    {
        auto &hostPlayer = playerLists[hostPlayerID];
        auto &clientPlayer = playerLists[clientPlayerID];

        generateCardsForEachMode(host, hostPlayer, nullptr, clientPlayer);
        while (!isEndGame(hostPlayerID))
        {
            hostPlayer = playerLists[hostPlayerID];
            clientPlayer = playerLists[clientPlayerID];
            // Host receives client's choice
            unsigned int clientChoiceCard = host->receivePlayerChoice();
            // Handle client's turn
            handlingPlayerTurn(clientPlayerID, clientChoiceCard, playerLists);
            updateUi(Ui::WAIT_FOR_CONFIRM, playerLists, hostPlayerID, clientChoiceCard);

            // Host plays its card
            unsigned int cardPlayed = hostPlayer.pickACardToPlay();
            host->sendPlayerChoice(cardPlayed);

            // Handle host's turn
            handlingPlayerTurn(hostPlayerID, cardPlayed, playerLists);
            updateUi(Ui::WAIT_NEXT_TURN, playerLists, hostPlayerID, clientChoiceCard);
        }
        unsigned int empty;
        updateUi(Ui::RESULT, playerLists, hostPlayerID, empty);
    }
}

void Engine::startClientMode(MySocket *client)
{
    if (client != nullptr)
    {
        auto &hostPlayer = playerLists[hostPlayerID];
        auto &clientPlayer = playerLists[clientPlayerID];

        // Client receives host's card choices
        generateCardsForEachMode(nullptr, hostPlayer, client, clientPlayer);
        while (!isEndGame(hostPlayerID))
        {
            hostPlayer = playerLists[hostPlayerID];
            clientPlayer = playerLists[clientPlayerID];
            // Client plays its card
            unsigned int cardPlayed = clientPlayer.pickACardToPlay();
            client->sendPlayerChoice(cardPlayed);
            // Handle client's turn
            handlingPlayerTurn(clientPlayerID, cardPlayed, playerLists);
            updateUi(Ui::WAIT_NEXT_TURN, playerLists, clientPlayerID, cardPlayed);

            // Client receives host's choice
            unsigned int serverChoiceCard = client->receivePlayerChoice();

            // Handle host's turn
            handlingPlayerTurn(hostPlayerID, serverChoiceCard, playerLists);
            updateUi(Ui::WAIT_FOR_CONFIRM, playerLists, hostPlayerID, serverChoiceCard);
        }
        unsigned int empty;
        updateUi(Ui::RESULT, playerLists, hostPlayerID, empty);
    }
}

void Engine::startSingleMode()
{
    unsigned int cardChoiced;
    while (playerLists[currentTurn].getHero()->IsAlive())
    {
        auto &currentPlayer = playerLists[currentTurn];
        auto &opponentPlayer = playerLists[nextTurn];
        unsigned int cardPlayed = currentPlayer.pickACardToPlay();
        handlingPlayerTurn((PlayerId)currentTurn, cardPlayed, playerLists);
        updateUi(Ui::WAIT_FOR_CONFIRM, playerLists, (PlayerId)currentTurn, cardPlayed);
        std::swap(currentTurn, nextTurn);
    }
    updateUi(Ui::RESULT, playerLists, (PlayerId)currentTurn, cardChoiced);
}

void Engine::handlingPlayerTurn(PlayerId playerID, unsigned int cardPlayed, std::vector<Player> &players)
{
    auto cardIterator = players[playerID].getHand()[cardPlayed];

    if (cardIterator->getCardType() != CardType::BRAWL)
    {
        players[playerID].addCardToBattle(players[playerID].getHand().begin() + cardPlayed);
        cardIterator->play(playerID, players);
        players[playerID].getHand().erase(players[playerID].getHand().begin() + cardPlayed);
    }
    else
    {
        cardIterator->play(playerID, players);
        players[playerID].getHand().erase(players[playerID].getHand().begin() + cardPlayed);
    }
    updateUi(Ui::UPDATE_BATTLE, players, playerID, cardPlayed);
    for (size_t playerIndex = 0; playerIndex < MAX_PLAYER; playerIndex++)
    {
        players[playerIndex].stats.clear();
    }
}

void Engine::generateCardsForEachMode(MySocket *host, Player &hostPlayer, MySocket *client, Player &clientPlayer)
{
    if (client != nullptr)
    {
        client->recvInitCardPool(hostPlayer, clientPlayer);
    }
    if (host != nullptr)
    {
        host->sendInitCardPool(hostPlayer.getHand(), clientPlayer.getHand());
    }
}

void Engine::addUiObserver(Ui *subUi)
{
    uiObs = subUi;
}

void Engine::updateUi(Ui::UiState state, std::vector<Player> &players, PlayerId playerId, unsigned int &clone)
{
    uiObs->updateUiOnState(state, players, playerId, clone);
}

Engine::~Engine()
{
}