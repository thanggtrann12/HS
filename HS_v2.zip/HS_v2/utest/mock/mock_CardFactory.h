#ifndef MOCK_CARDFACTORY_H
#define MOCK_CARDFACTORY_H

 #include "gtest/gtest.h"
 #include "gmock/gmock.h"
#include "Card/CardFactory.h"

// Mock class for Mock_CardFactory
class Mock_CardFactory : public CardFactory {
public:
};
#endif // MOCK_CARDFACTORY_H
