#ifndef MOCK_HERODATA_H
#define MOCK_HERODATA_H

 #include "gtest/gtest.h"
 #include "gmock/gmock.h"
#include "assets/HeroData.h"

// Mock class for Mock_HeroData
class Mock_HeroData : public HeroData {
public:
};
#endif // MOCK_HERODATA_H
