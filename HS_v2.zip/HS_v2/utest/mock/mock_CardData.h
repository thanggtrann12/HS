#ifndef MOCK_CARDDATA_H
#define MOCK_CARDDATA_H

 #include "gtest/gtest.h"
 #include "gmock/gmock.h"
#include "assets/CardData.h"

// Mock class for Mock_CardData
class Mock_CardData : public CardData {
public:
};
#endif // MOCK_CARDDATA_H
